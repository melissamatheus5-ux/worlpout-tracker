"use client";
import { useState, useEffect } from "react";

const workoutPlan = {
  "Day 1": [
    "Squats",
    "Bulgarian Split Squats",
    "Hip Thrusts",
    "Romanian Deadlifts"
  ],
  "Day 2": [
    "Bench Press",
    "Shoulder Press",
    "Lat Pulldown",
    "Bicep Curl",
    "Tricep Pulldown"
  ],
  "Day 3": [
    "Hip Thrusts",
    "Glute Bridges",
    "Cable Kickbacks",
    "Plank",
    "Leg Extension"
  ]
};

export default function WorkoutTracker() {
  const [completed, setCompleted] = useState({});
  const [weights, setWeights] = useState({});
  const [notes, setNotes] = useState({});
  const [history, setHistory] = useState({});

  useEffect(() => {
    const savedCompleted = localStorage.getItem("completed");
    const savedWeights = localStorage.getItem("weights");
    const savedNotes = localStorage.getItem("notes");
    const savedHistory = localStorage.getItem("history");

    if (savedCompleted) setCompleted(JSON.parse(savedCompleted));
    if (savedWeights) setWeights(JSON.parse(savedWeights));
    if (savedNotes) setNotes(JSON.parse(savedNotes));
    if (savedHistory) setHistory(JSON.parse(savedHistory));
  }, []);

  useEffect(() => {
    localStorage.setItem("completed", JSON.stringify(completed));
  }, [completed]);

  useEffect(() => {
    localStorage.setItem("weights", JSON.stringify(weights));
  }, [weights]);

  useEffect(() => {
    localStorage.setItem("notes", JSON.stringify(notes));
  }, [notes]);

  useEffect(() => {
    localStorage.setItem("history", JSON.stringify(history));
  }, [history]);

  const toggleExercise = (day, exercise) => {
    const key = `${day}-${exercise}`;
    setCompleted(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const handleWeightChange = (day, exercise, value) => {
    const key = `${day}-${exercise}`;
    setWeights(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handleNotesChange = (day, exercise, value) => {
    const key = `${day}-${exercise}`;
    setNotes(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const saveWorkout = () => {
    const newHistory = { ...history };

    Object.keys(weights).forEach(key => {
      newHistory[key] = {
        weight: weights[key],
        notes: notes[key]
      };
    });

    setHistory(newHistory);
  };

  return (
    <div style={{ padding: 20, display: "grid", gap: 20, maxWidth: 500, margin: "auto" }}>
      <button onClick={saveWorkout} style={{ padding: 10, borderRadius: 10, fontWeight: "bold" }}>
        Save Workout
      </button>

      {Object.entries(workoutPlan).map(([day, exercises]) => (
        <div key={day} style={{ border: "1px solid #ddd", borderRadius: 16, padding: 16 }}>
          <h2 style={{ fontSize: 20, fontWeight: "bold", marginBottom: 10 }}>{day}</h2>

          {exercises.map(ex => {
            const key = `${day}-${ex}`;
            const last = history[key];

            return (
              <div key={key} style={{ marginBottom: 12, padding: 10, borderRadius: 10, border: "1px solid #eee", opacity: completed[key] ? 0.5 : 1 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span style={{ textDecoration: completed[key] ? "line-through" : "none" }}>{ex}</span>
                  <button onClick={() => toggleExercise(day, ex)}>
                    {completed[key] ? "Done" : "Mark"}
                  </button>
                </div>

                {last && (
                  <div style={{ fontSize: 12, marginTop: 4, color: "#555" }}>
                    Last: {last.weight || "-"} lbs | {last.notes || "no notes"}
                  </div>
                )}

                <div style={{ marginTop: 8, display: "flex", gap: 8 }}>
                  <input
                    type="number"
                    placeholder="Weight"
                    value={weights[key] || ""}
                    onChange={e => handleWeightChange(day, ex, e.target.value)}
                    style={{ flex: 1, padding: 6 }}
                  />
                  <span>lbs</span>
                </div>

                <textarea
                  placeholder="Notes (form, difficulty, PR, etc.)"
                  value={notes[key] || ""}
                  onChange={e => handleNotesChange(day, ex, e.target.value)}
                  style={{ width: "100%", marginTop: 8, minHeight: 60, padding: 8, borderRadius: 8, border: "1px solid #ccc" }}
                />
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
}
